prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8637757499604067
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PRIOSS'
);
wwv_flow_imp_page.create_page(
 p_id=>30
,p_name=>'Ticketboard'
,p_alias=>'TICKETBOARD'
,p_step_title=>'Ticketboard'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function handleDrag(event) ',
'{',
'      var data = {int_key: event.target.dataset.int_key, status: event.target.dataset.status};',
'      var json_data = JSON.stringify(data);',
'      event.dataTransfer.setData(''data'', json_data);',
'}',
'',
'function handleDragover(event)//This is just so nothing happens, when dragging over (not dropping) something',
'{',
'      event.preventDefault();',
'}',
'',
'function handleDrop(event, target_state)',
'{',
'    var int_key = JSON.parse(event.dataTransfer.getData(''data'')).int_key;',
'    var state = target_state;//this is the STATE_OF_THIS_REGION-String that we passed to the function using the html-callbacks above',
'',
'    apex.server.process(',
'        ''UpdateTODO'',//This must match the name of the Ajax Callback we defined above',
'        {',
'            x01: state,',
'            x02: int_key',
'        },',
'        {',
'            success: function() ',
'            {',
'                //These calls refresh the regions with the static IDs TODO, IN_PROGRESS and DONE, make sure they match the static IDs you chose for your regions',
'                apex.event.trigger(''#TODO'', ''apexrefresh'');',
'                apex.event.trigger(''#IN_PROGRESS'', ''apexrefresh'');',
'                apex.event.trigger(''#DONE'', ''apexrefresh'');',
'            },',
'            dataType: ''text''',
'        }',
'    );',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.todos {',
'      list-style-type: none;',
'}',
'',
'.todo-el {',
'      padding: 10px;',
'}',
'',
'.t-ticket-column {',
'    min-height: 100%;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'SIMON'
,p_last_upd_yyyymmddhh24miss=>'20230807142629'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9019070610016013)
,p_name=>'To Do'
,p_region_name=>'TODO'
,p_template=>wwv_flow_imp.id(8712279463620007)
,p_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'t-ticket-column'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'ondragover="handleDragover(event)" ondrop="handleDrop(event, ''TODO'')"'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select t.INT_KEY,',
'        t.SPRINT_IK,',
'        t.TITLE,',
'        t.DESCRIPTION,',
'        LISTAGG(distinct u.first_name || '' '' || u.last_name, '', '') WITHIN GROUP (ORDER BY u.first_name || '' '' || u.last_name)  ASSIGNEES,',
'        t.STATUS,',
'        apex_page.get_url(  p_page                  => 31,',
'                            p_items                 => ''P31_INT_KEY,P31_PROJECT_IK'',',
'                            p_values                => t.INT_KEY || '','' || :P30_PROJECT_IK,',
'                            p_triggering_element    => ''$(''''#CREATE_TICKET_BTN'''')'')',
'            as LINK',
'   from TI_TICKET t',
'     -- wildcard join',
'   join table(apex_string.split(:P30_FILTER_TEAM, '':'')) filter_team',
'     on :P30_FILTER_TEAM is null ',
'        or upper(filter_team.column_value) = ''NULL''',
'        or upper(t.TITLE) like ''%'' || upper(filter_team.column_value) || ''%''',
'          ',
'     -- normal joins',
'   left join TI_USER_TICKET_ASSIGN a',
'     on t.int_key = a.ticket_ik',
'   left join TI_USER u',
'     on a.user_ik = u.int_key',
'',
'  where STATUS = ''TODO'' and t.sprint_ik = :P30_SPRINT_IK',
' having (:P30_FILTER_ASSIGNEE is null or :P30_FILTER_ASSIGNEE in (LISTAGG(u.int_key, '','') WITHIN GROUP (ORDER BY u.last_name)))',
'  group ',
'     by t.INT_KEY,',
'        t.SPRINT_IK,',
'        t.TITLE,',
'        t.DESCRIPTION,',
'        t.STATUS'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P30_SPRINT_IK,P30_PROJECT_IK,P30_FILTER_TEAM,P30_FILTER_ASSIGNEE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(9070804475215940)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9019147746016014)
,p_query_column_id=>1
,p_column_alias=>'INT_KEY'
,p_column_display_sequence=>10
,p_column_heading=>'Int Key'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9019257344016015)
,p_query_column_id=>2
,p_column_alias=>'SPRINT_IK'
,p_column_display_sequence=>20
,p_column_heading=>'Sprint Ik'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9019309150016016)
,p_query_column_id=>3
,p_column_alias=>'TITLE'
,p_column_display_sequence=>30
,p_column_heading=>'Title'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9019440576016017)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>40
,p_column_heading=>'Description'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9022311762016046)
,p_query_column_id=>5
,p_column_alias=>'ASSIGNEES'
,p_column_display_sequence=>60
,p_column_heading=>'Assignees'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9019501108016018)
,p_query_column_id=>6
,p_column_alias=>'STATUS'
,p_column_display_sequence=>50
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9129657970789612)
,p_query_column_id=>7
,p_column_alias=>'LINK'
,p_column_display_sequence=>70
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9019618127016019)
,p_name=>'In Progress'
,p_region_name=>'IN_PROGRESS'
,p_template=>wwv_flow_imp.id(8712279463620007)
,p_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'t-ticket-column'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'ondragover="handleDragover(event)" ondrop="handleDrop(event, ''IN_PROGRESS'')"'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select t.INT_KEY,',
'        t.SPRINT_IK,',
'        t.TITLE,',
'        t.DESCRIPTION,',
'        LISTAGG(distinct u.first_name || '' '' || u.last_name, '', '') WITHIN GROUP (ORDER BY u.first_name || '' '' || u.last_name)  ASSIGNEES,',
'        t.STATUS,',
'        apex_page.get_url(  p_page                  => 31,',
'                            p_items                 => ''P31_INT_KEY,P31_PROJECT_IK'',',
'                            p_values                => t.INT_KEY || '','' || :P30_PROJECT_IK,',
'                            p_triggering_element    => ''$(''''#CREATE_TICKET_BTN'''')'')',
'        as LINK',
'   from TI_TICKET t',
'     -- wildcard join',
'   join table(apex_string.split(:P30_FILTER_TEAM, '':'')) filter_team',
'     on :P30_FILTER_TEAM is null ',
'        or upper(filter_team.column_value) = ''NULL''',
'        or upper(t.TITLE) like ''%'' || upper(filter_team.column_value) || ''%''',
'     -- normal joins',
'   left join TI_USER_TICKET_ASSIGN a',
'     on t.int_key = a.ticket_ik',
'   left join TI_USER u',
'     on a.user_ik = u.int_key',
'  where STATUS = ''IN_PROGRESS'' and t.sprint_ik = :P30_SPRINT_IK',
' having (:P30_FILTER_ASSIGNEE is null or :P30_FILTER_ASSIGNEE in (LISTAGG(u.int_key, '','') WITHIN GROUP (ORDER BY u.last_name)))',
'  group ',
'     by t.INT_KEY,',
'        t.SPRINT_IK,',
'        t.TITLE,',
'        t.DESCRIPTION,',
'        t.STATUS'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P30_SPRINT_IK,P30_PROJECT_IK,P30_FILTER_TEAM,P30_FILTER_ASSIGNEE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(9070804475215940)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9019745393016020)
,p_query_column_id=>1
,p_column_alias=>'INT_KEY'
,p_column_display_sequence=>10
,p_column_heading=>'Int Key'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9019877471016021)
,p_query_column_id=>2
,p_column_alias=>'SPRINT_IK'
,p_column_display_sequence=>20
,p_column_heading=>'Sprint Ik'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9019920998016022)
,p_query_column_id=>3
,p_column_alias=>'TITLE'
,p_column_display_sequence=>30
,p_column_heading=>'Title'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9020071852016023)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>40
,p_column_heading=>'Description'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9129289970789608)
,p_query_column_id=>5
,p_column_alias=>'ASSIGNEES'
,p_column_display_sequence=>60
,p_column_heading=>'Assignees'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9020192572016024)
,p_query_column_id=>6
,p_column_alias=>'STATUS'
,p_column_display_sequence=>50
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9189314197926911)
,p_query_column_id=>7
,p_column_alias=>'LINK'
,p_column_display_sequence=>70
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(9020280767016025)
,p_name=>'Done'
,p_region_name=>'DONE'
,p_template=>wwv_flow_imp.id(8712279463620007)
,p_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'t-ticket-column'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'ondragover="handleDragover(event)" ondrop="handleDrop(event, ''DONE'')"'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select t.INT_KEY,',
'        t.SPRINT_IK,',
'        t.TITLE,',
'        t.DESCRIPTION,',
'        LISTAGG(distinct u.first_name || '' '' || u.last_name, '', '') WITHIN GROUP (ORDER BY u.first_name || '' '' || u.last_name)  ASSIGNEES,',
'        t.STATUS,',
'        apex_page.get_url(  p_page                  => 31,',
'                            p_items                 => ''P31_INT_KEY,P31_PROJECT_IK'',',
'                            p_values                => t.INT_KEY || '','' || :P30_PROJECT_IK,',
'                            p_triggering_element    => ''$(''''#CREATE_TICKET_BTN'''')'')',
'        as LINK',
'   from TI_TICKET t',
'     -- wildcard join',
'   join table(apex_string.split(:P30_FILTER_TEAM, '':'')) filter_team',
'     on :P30_FILTER_TEAM is null ',
'        or upper(filter_team.column_value) = ''NULL''',
'        or upper(t.TITLE) like ''%'' || upper(filter_team.column_value) || ''%''',
'     -- normal joins',
'   left join TI_USER_TICKET_ASSIGN a',
'     on t.int_key = a.ticket_ik',
'   left join TI_USER u',
'     on a.user_ik = u.int_key',
'  where STATUS = ''DONE'' and t.sprint_ik = :P30_SPRINT_IK',
' having (:P30_FILTER_ASSIGNEE is null or :P30_FILTER_ASSIGNEE in (LISTAGG(u.int_key, '','') WITHIN GROUP (ORDER BY u.last_name)))',
'  group ',
'     by t.INT_KEY,',
'        t.SPRINT_IK,',
'        t.TITLE,',
'        t.DESCRIPTION,',
'        t.STATUS'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P30_SPRINT_IK,P30_PROJECT_IK,P30_FILTER_TEAM,P30_FILTER_ASSIGNEE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(9070804475215940)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9020368029016026)
,p_query_column_id=>1
,p_column_alias=>'INT_KEY'
,p_column_display_sequence=>10
,p_column_heading=>'Int Key'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9020423887016027)
,p_query_column_id=>2
,p_column_alias=>'SPRINT_IK'
,p_column_display_sequence=>20
,p_column_heading=>'Sprint Ik'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9020597014016028)
,p_query_column_id=>3
,p_column_alias=>'TITLE'
,p_column_display_sequence=>30
,p_column_heading=>'Title'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9020698471016029)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>40
,p_column_heading=>'Description'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9129357461789609)
,p_query_column_id=>5
,p_column_alias=>'ASSIGNEES'
,p_column_display_sequence=>60
,p_column_heading=>'Assignees'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9020771877016030)
,p_query_column_id=>6
,p_column_alias=>'STATUS'
,p_column_display_sequence=>50
,p_column_heading=>'Status'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(9189433443926912)
,p_query_column_id=>7
,p_column_alias=>'LINK'
,p_column_display_sequence=>70
,p_column_heading=>'Link'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9068585345184387)
,p_plug_name=>'&P30_SPRINT_TITLE.'
,p_icon_css_classes=>'fa-badge-list'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8752031078620028)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(8643227543619878)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(8820455786620117)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9020984450016032)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(9019070610016013)
,p_button_name=>'CREATE_TICKET'
,p_button_static_id=>'CREATE_TICKET_BTN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--hoverIconPush'
,p_button_template_id=>wwv_flow_imp.id(8818982381620116)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create Ticket'
,p_button_position=>'EDIT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus-square-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9018946994016012)
,p_name=>'P30_SPRINT_IK'
,p_item_sequence=>10
,p_prompt=>'Sprint'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'SPRINTS'
,p_lov=>'select * from TI_SPRINT where project_ik = v(''P'' || :APP_PAGE_ID || ''_PROJECT_IK'')'
,p_lov_cascade_parent_items=>'P30_PROJECT_IK'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(8816399209620104)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9130901974789625)
,p_name=>'P30_SPRINT_TITLE'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9131911286789635)
,p_name=>'P30_DIALOG_URL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(9019070610016013)
,p_item_display_point=>'EDIT'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9132136311789637)
,p_name=>'P30_FILTER_TEAM'
,p_item_sequence=>20
,p_prompt=>'Filter by Team'
,p_source=>'NULL'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'TEAM_LABELS'
,p_lov=>'.'||wwv_flow_imp.id(24847355383576883)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Display Everything'
,p_lov_null_value=>'NULL'
,p_cSize=>30
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(8816399209620104)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_03=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_11=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9132611176789642)
,p_name=>'P30_FILTER_ASSIGNEE'
,p_item_sequence=>30
,p_prompt=>'Filter by Assignee'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'USERS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
' select int_key, ',
'        first_name || '' '' || last_name name',
'  from TI_USER'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Show All'
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(8816399209620104)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9188304040926901)
,p_name=>'P30_PROJECT_IK'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(9131040790789626)
,p_computation_sequence=>10
,p_computation_item=>'P30_SPRINT_TITLE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>'select title || '': '' || start_date || '' - '' || end_date || '''' from ti_sprint where int_key = :P30_SPRINT_IK'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(9131385488789629)
,p_computation_sequence=>20
,p_computation_item=>'A_LAST_ACCESSED_PROJECT_IK'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>':P30_PROJECT_IK'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9021106077016034)
,p_name=>'On Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9020984450016032)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9021233237016035)
,p_event_id=>wwv_flow_imp.id(9021106077016034)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9019070610016013)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9021365875016036)
,p_event_id=>wwv_flow_imp.id(9021106077016034)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9019618127016019)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9021445581016037)
,p_event_id=>wwv_flow_imp.id(9021106077016034)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9020280767016025)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9129926102789615)
,p_name=>'On Filter Change'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P30_SPRINT_IK,P30_FILTER_TEAM,P30_FILTER_ASSIGNEE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9130138975789617)
,p_event_id=>wwv_flow_imp.id(9129926102789615)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9019070610016013)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9130202632789618)
,p_event_id=>wwv_flow_imp.id(9129926102789615)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9019618127016019)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9130363321789619)
,p_event_id=>wwv_flow_imp.id(9129926102789615)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(9020280767016025)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9131757973789633)
,p_name=>'On Click Create Ticket'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9020984450016032)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9131859555789634)
,p_event_id=>wwv_flow_imp.id(9131757973789633)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Generate Dialog URL'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P30_DIALOG_URL := apex_page.get_url(',
'    p_page   => ''31'',',
'	p_items  => ''P31_STATUS,P31_STATUS_EDIT,P31_PROJECT_IK,P31_SPRINT_IK'',',
'    p_values => ''TODO,TODO,'' || :P30_PROJECT_IK || '','' || :P30_SPRINT_IK,',
'   	p_triggering_element => ''$(''''#CREATE_TICKET_BTN'''')''',
');'))
,p_attribute_02=>'P30_PROJECT_IK,P30_SPRINT_IK'
,p_attribute_03=>'P30_DIALOG_URL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9132057955789636)
,p_event_id=>wwv_flow_imp.id(9131757973789633)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Call Dialog URL'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'eval(apex.item("P30_DIALOG_URL").getValue());'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9021980942016042)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Save Last Accessed Sprint'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P30_SPRINT_IK is not null',
'then',
'    update ti_user set last_access_sprint_ik = :P30_SPRINT_IK where user_name = :APP_USER;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>9021980942016042
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9020868553016031)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UpdateTODO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_debug.info(''STATUS: '' || apex_application.g_x01);',
'apex_debug.info(''INT_KEY: '' || apex_application.g_x02);',
'',
'if apex_application.g_x01 = ''TODO'' ',
'then',
'    UPDATE TI_TICKET SET STATUS = ''TODO'' WHERE INT_KEY = apex_application.g_x02;',
'',
'elsif apex_application.g_x01 = ''IN_PROGRESS'' ',
'then',
'    UPDATE TI_TICKET SET STATUS = ''IN_PROGRESS'' WHERE INT_KEY = apex_application.g_x02;',
'',
'elsif apex_application.g_x01 = ''DONE'' ',
'then',
'    UPDATE TI_TICKET SET STATUS = ''DONE'' WHERE INT_KEY = apex_application.g_x02;',
'    ',
'else',
'    apex_debug.error(''Unknown State String passed to Ajax Callback for handling drop!'');',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>9020868553016031
);
wwv_flow_imp.component_end;
end;
/
