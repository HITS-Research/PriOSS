prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8637757499604067
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PRIOSS'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'PriOSS Ticketing'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'SIMON'
,p_last_upd_yyyymmddhh24miss=>'20230214104121'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8856910579620334)
,p_plug_name=>'PriOSS Ticketing'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(8752031078620028)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9022022681016043)
,p_plug_name=>'Last Accessed Sprint'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--noUI:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8712279463620007)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select s.INT_KEY,',
'       s.PROJECT_IK,',
'       s.START_DATE || '' - '' || s.END_DATE date_range,',
'       s.TITLE,',
'       s.GOAL',
'  from TI_USER u',
'  join TI_SPRINT s',
'    on u.last_access_sprint_ik = s.int_key',
' where u.user_name = :APP_USER'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(9022164759016044)
,p_region_id=>wwv_flow_imp.id(9022022681016043)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'DATE_RANGE'
,p_body_adv_formatting=>false
,p_body_column_name=>'GOAL'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-badge-list'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'INT_KEY'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(9022296193016045)
,p_card_id=>wwv_flow_imp.id(9022164759016044)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::P30_SPRINT_IK,P30_PROJECT_IK:&INT_KEY.,&PROJECT_IK.'
);
wwv_flow_imp.component_end;
end;
/
