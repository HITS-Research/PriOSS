prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8637757499604067
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PRIOSS'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE900000106494441545847637C191DF29F610001E3A8034643603404864C08BC131261E03530C45962BCBA788181EBD95306417636924A';
wwv_flow_imp.g_varchar2_table(2) := '15A2CB81DFCE6E0C623E01380DBFDFD5C2C0C1C1C9F0FDC675921C41550748A86B307C78F890244750CD014FE6CD64F8F3E60D3884BEFEFAC520F5F635515141350720DBF66ACB0606D6BDBB68EF80AF17CF3370EB63264CBA38E0D389A3601FF2595833';
wwv_flow_imp.g_varchar2_table(3) := 'BCDABC1EEE5B31DF40069A3AE0D182D90CBC720A0CCC5C5C60CB41006421030323982DE6E34F5B07FCFBFE8DE1FBAD1B0CDCFA46B8CB047AA5015C2EA06914205B3A9A084713215D1321B83A363426AA78FD7AE12C83C05B48BD4008105D171032885CF9';
wwv_flow_imp.g_varchar2_table(4) := '51078C86C068080C780800006ABCE801B19237200000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(8845114847620210)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
