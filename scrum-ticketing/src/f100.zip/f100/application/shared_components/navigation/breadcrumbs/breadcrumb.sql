prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8637757499604067
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PRIOSS'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(8643227543619878)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8643456920619881)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(8975053878621668)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(9016113063014784)
,p_short_name=>'Projects'
,p_link=>'f?p=&APP_ID.:10:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(9033617041039937)
,p_parent_id=>wwv_flow_imp.id(9016113063014784)
,p_short_name=>'Sprints'
,p_link=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::P20_PROJECT_IK:&A_LAST_ACCESSED_PROJECT_IK.'
,p_page_id=>20
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(9068942400184387)
,p_parent_id=>wwv_flow_imp.id(9033617041039937)
,p_short_name=>'Ticketboard'
,p_link=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.:::'
,p_page_id=>30
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(9103316635469181)
,p_short_name=>'Users'
,p_link=>'f?p=&APP_ID.:9000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>9000
);
wwv_flow_imp.component_end;
end;
/
