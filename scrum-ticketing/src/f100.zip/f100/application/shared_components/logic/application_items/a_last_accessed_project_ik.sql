prompt --application/shared_components/logic/application_items/a_last_accessed_project_ik
begin
--   Manifest
--     APPLICATION ITEM: A_LAST_ACCESSED_PROJECT_IK
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8637757499604067
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PRIOSS'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(24838490081447340)
,p_name=>'A_LAST_ACCESSED_PROJECT_IK'
,p_protection_level=>'I'
);
wwv_flow_imp.component_end;
end;
/
