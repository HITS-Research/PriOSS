prompt --application/shared_components/user_interface/templates/report/dragdropreport
begin
--   Manifest
--     ROW TEMPLATE: DRAGDROPREPORT
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8637757499604067
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PRIOSS'
);
wwv_flow_imp_shared.create_row_template(
 p_id=>wwv_flow_imp.id(9070804475215940)
,p_row_template_name=>'DragDropReport'
,p_internal_name=>'DRAGDROPREPORT'
,p_row_template1=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>',
'    <li data-int_key=''#INT_KEY#'' data-state=''#STATE#'' class=''todo-el'' draggable=true class="">',
'        <div class="a-CardView has-title has-subtitle has-body has-icon has-icon--start has-media has-media--background has-media--cover has-actions has-actions--full"',
'            style="background-color: #404040">',
'                <span class="u-vh">#TITLE#</span>',
'            ',
'            <div class="a-CardView-header">',
'                <div class="a-CardView-headerBody">',
'                    <h3 class="a-CardView-title ">#TITLE#</h3>',
'                    <h4 class="a-CardView-subTitle ">#ASSIGNEES#</h4>',
'                </div>',
'                <a href="#LINK#" style="display:grid; grid-row-start: body; grid-row-end: body; grid-column-start: body+1; grid-column-end: body;">',
'                    <button type="button" class="t-Button t-Button--noLabel t-Button--icon" style="background-color: var(--a-menu-focused-background-color); color: white;">',
'                        <span aria-hidden="true" class="t-Icon fa fa-edit">',
'                        </span>',
'                    </button>',
'                </a>',
'            </div>',
'            <!--',
'            <div class="a-CardView-body">',
'                <div class="a-CardView-mainContent ">#DESCRIPTION#</div>',
'            </div>',
'            -->',
'        </div>',
'    </li>',
'</div>'))
,p_row_template_before_rows=>'  <ul class=''todos'' ondragstart=''handleDrag(event)''>'
,p_row_template_after_rows=>'  </ul>'
,p_row_template_type=>'NAMED_COLUMNS'
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_theme_id=>42
,p_theme_class_id=>4
);
wwv_flow_imp.component_end;
end;
/
