prompt --application/shared_components/user_interface/lovs/apex_users
begin
--   Manifest
--     APEX_USERS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8637757499604067
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PRIOSS'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9117385066482797)
,p_lov_name=>'APEX_USERS'
,p_lov_query=>'select user_name from APEX_WORKSPACE_APEX_USERS'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'USER_NAME'
,p_display_column_name=>'USER_NAME'
,p_default_sort_column_name=>'USER_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
