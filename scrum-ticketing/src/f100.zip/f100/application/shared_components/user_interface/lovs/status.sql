prompt --application/shared_components/user_interface/lovs/status
begin
--   Manifest
--     STATUS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>8637757499604067
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_PRIOSS'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9092434233329007)
,p_lov_name=>'STATUS'
,p_lov_query=>'.'||wwv_flow_imp.id(9092434233329007)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9092725208329007)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'To Do'
,p_lov_return_value=>'TODO'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9093131876329008)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'In Progress'
,p_lov_return_value=>'IN_PROGRESS'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(9093518377329008)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Done'
,p_lov_return_value=>'DONE'
);
wwv_flow_imp.component_end;
end;
/
